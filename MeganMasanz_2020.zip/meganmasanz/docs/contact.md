# Megan Masanz

:fa-map: Eagan, MN 55077 

:fa-phone: 651-308-3365

:fa-envelope-square: <meganmasanz.work@gmail.com>

:fa-linkedin-square: [linkedin.com/in/megan-masanz](https://www.linkedin.com/in/megan-masanz-a015a02/)

:fa-file: [Resume for Download](https://github.com/megado123/resume/blob/master/MeganMasanz_2020.pdf?raw=true)