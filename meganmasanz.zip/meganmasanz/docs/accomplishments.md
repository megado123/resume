# Megan Masanz

## Work Related

![Screenshot](img/architecture.jpeg)

- 2019 Self-Service Data & Analytics Platform

    - Collection: Collecting data from disparate source systems

    - Organization: Business Driven data model supporting reliable and effective storage

    - Preservation: Automating tagging data-sets based on REST API meta-data collection to cataloging of datasets

    - Transformation: Support reformatting for use by different tools or to match new format standards

    - Workflow & Integration: Support the ability to systematize data workflows

    - Discoverability & Sharing: Support sharing data between researchers, teams, and business groups

    - Provenance: Support identifying what inputs and calculations are responsible for data values

    - Modification: Support management of corrections and updates

    - Compliance: Ensure compliance to legal, regulatory, and local policy requirements

    - Security: Ensure that data is secure from tampering or inappropriate access and distribution


## Education Related

Most repositories are marked as private, but repos can be made available apon request

**CS598 Data Curation**

- [CS598: Data Curation Course Certification](https://coursera.org/share/85740d888dfa0b2485cdca4d1060b309)  
  
- Examining theory behind dataset life-cycle management. 

- Exploring metadata to provide data linage and exploration. 


**CS498 Cloud Computing Applications**

- [CS498: Cloud Computing Applications Course Certification](https://coursera.org/share/907ea1215c63afcca0c9a052e54c1685)

- CS498: Final Project repo

- Project Data Flow

![Screenshot](img/CS498DataFlow.png)

**CS498 Data Visualization**

- [CS498: Data Visualization Course Certification](https://coursera.org/share/43edcddb3944682c38d0ddfed7c2b089)
- Leveraging D3 **without** the use of a web framework [website](https://megado123.github.io/)

![Screenshot](img/dataviz.PNG)

**CS410 Text Information Systems**

- [CS410: Text Information Systems Course Certification](https://coursera.org/share/51dba734f130aeb028cc9d7679d2d017)

- [CS410: YouTube Video](https://www.youtube.com/watch?v=6pafuFNN4Dg&t=1430s)

- [CS410: Final Project repo](https://github.com/megado123/searchpatent)

![Screenshot](img/WordCloud.PNG)


- Flask python jinja2 web application utilizing Azure Search and D3 visualizations against Patent Database

 - Present form to end user for search criteria
 - Provide criteria to the Azure Search API and receive results set
 - Identify word tokens by frequency using the patent titles.
 - Identify topics in the search results. Latent Dirichlet Allocation (LDA) and the Hierarchical Dirichlet Allocation (HDP) - methods are utilized to generate topic models and both models are displayed.
 - Display results including patent meta data and patent abstract for browsing.


**Stats 420 Statistical Modeling in R**

- [Stats 420 Course Certification](https://coursera.org/share/590743ec37cc37816918800a5d9dac83)